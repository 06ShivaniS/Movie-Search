
import {Routes, Route, Router } from "react-router-dom";
import Home from './Home';
import Error from './Error';
import Movies from './Movies';


function App() {
  

  return (

    <>
    <Routes>
      <Route path='/' element={<Movies/>}/>
      <Route path='movie/:id' element={<Home/>}/>
      <Route path="*" element={<Error/>}/>
    </Routes>
    </>
  )
}

export default App
