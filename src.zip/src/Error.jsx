import React from 'react'

const Error = () => {
  return (
    <>
    <h1>error</h1>
    </>
  )
}

export default Error