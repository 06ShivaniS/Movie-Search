import React from 'react'
import { useContext } from 'react';
import { AppContext } from './Context'

const Movies = () => {
  const {Movie} = useContext(AppContext);
  console.log(Movie)
  return (
    <>
    {Movie.map((items)=>{<div><h2>{items.Title}</h2></div>})}

    <div><h1>hello</h1></div>

    </>
  )
  
}

export default Movies