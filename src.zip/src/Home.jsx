import React from 'react';



const Home = () => {

    
  return (
    <>

    <div>this my home page</div>
    
    </>
  )
}

export default Home