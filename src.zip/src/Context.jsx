import { children } from "react";
import React from "react";
import { useEffect, useState } from "react";

const API = "https://www.omdbapi.com/?i=tt3896198&apikey=7f0774cd&s=batman"

const  AppContext = React.createContext();



const AppProvider = ({children})=>{

    let [Isloading, setIsloading] = useState(true);
    let [Movie,setMovie] = useState([]);
    let [IsError,setIsError] = useState({show:"false", msg:"" })

const getmovies = async (url)=>{

    fetch(url).then((res)=>res.json()).then((data)=>setMovie(data.Search))

    console.log(Movie)
        // try{
        //     const res = await fetch (url);
        //     const data = await (res.json());
        //     setMovie(data.Search);
        //    console.log(Movie)
        // }
        // catch(error){
        //     console.log(error)
        // };

        
    };
    
    useEffect(()=>{

        getmovies(API)
    },[]);

    return(
        <AppContext.Provider value={{IsError,Isloading,Movie,}}>{children}</AppContext.Provider>
    )
};



export {AppContext, AppProvider, }